Proyecto Creado por : Danny Leonel De La A


******************************************************************************************************
Indicaciones del proyecto

1. El proyecto se ejecuta en 3 terminales

2. Para crear los ejecutables del proyecto se ejecuta el comando "make" en la consola("make clean" para eliminar los ejecutables)

3. el ejecutable "project" es el encargado de mostrar el estado de las barras y realizar las operaciones del reactor.

4. el ejecutable "az5" solo es para presionar ENTER al momento que el reactor esta en estado supercritico por mas de t*3 segundos.

5. el ejecutable "ingresar" es para poder modificar los valores de k.
******************************************************************************************************
